﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Back : MonoBehaviour {
	
	public void BackToMainMenu (string backTo) {
		Application.LoadLevel (backTo);
	}
}
